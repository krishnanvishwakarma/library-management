/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package kbc;

import java.awt.Color;
import java.util.Timer;
import java.util.TimerTask;
import javax.swing.JOptionPane;
import javax.swing.JRadioButton;

/**
 *
 * @author ADARSH
 */

public class Kbc4 extends javax.swing.JFrame {
    int question=0,a,b,m=0,counter =20,count=0;
    String y;
 JRadioButton jb5=new JRadioButton();
    /**
     * Creates new form Kbc4
     */
    public Kbc4() {
        initComponents();
         bg.add(jb5);
        bg.add(bt1);
        bg.add(bt2);
        bg.add(bt3);
        bg.add(bt4);
       t1.setVisible(false);
        bt1.setVisible(false);
        bt2.setVisible(false);
        bt3.setVisible(false);
        bt4.setVisible(false);
        bt5.setVisible(false);
        bt6.setVisible(false);
        bt7.setVisible(false);
        p1.setVisible(false);
        l2.setVisible(false);
        w1.setVisible(false);
        w2.setVisible(false);
        w3.setVisible(false);
        w4.setVisible(false);
        l4.setVisible(false);
        l3.setVisible(false);
        bt9.setVisible(false);
    }
    void bound(){
             if(Integer.parseInt(y)==1){
          tf1.setBackground(Color.lightGray);
         }
       else if(Integer.parseInt(y)==2){
          tf2.setBackground(Color.lightGray);
         }
       else if(Integer.parseInt(y)==3){
          tf3.setBackground(Color.lightGray);
         }
       else if(Integer.parseInt(y)==4){
          tf4.setBackground(Color.lightGray);
         }
       else if(Integer.parseInt(y)==5){
          tf5.setBackground(Color.lightGray);
         }
       else if(Integer.parseInt(y)==6){
          tf6.setBackground(Color.lightGray);
         }
       else if(Integer.parseInt(y)==7){
          tf7.setBackground(Color.lightGray);
         }
       else if(Integer.parseInt(y)==8){
          tf8.setBackground(Color.lightGray);
         }
       else if(Integer.parseInt(y)==9){
          tf9.setBackground(Color.lightGray);
         }
       else if(Integer.parseInt(y)==10){
          tf10.setBackground(Color.lightGray);
         }
       else if(Integer.parseInt(y)==11){
          tf11.setBackground(Color.lightGray);
         }
       else if(Integer.parseInt(y)==12){
          tf12.setBackground(Color.lightGray);
         }
       else if(Integer.parseInt(y)==13){
          tf13.setBackground(Color.lightGray);
         }
      }
    
    
    void start(){
        bound();      
        if(question<Integer.parseInt(y)){
            
       Timer timer = new Timer(); 
              if(question==0){ counter=19;  }
              else
              { counter=20; }
                            TimerTask task = new TimerTask() {         
                               public void run() {                
                            l2.setText(Integer.toString(counter)); //the timer lable to counter.
                            counter --;
                              if (count == 1){
                                 timer.cancel();}
                             if (counter == 0){
                                 timer.cancel();
                                 JOptionPane.showMessageDialog(null,"!!!Time Up!!!");
                             l4.setVisible(true);
                             l2.setVisible(false);
                             visible();
                             amount();
                             }
                              if(counter==9){
                               l2.setForeground(Color.YELLOW);}
                               if(counter==4){
                               l2.setForeground(Color.RED);
                              }
                              } };
                            timer.scheduleAtFixedRate(task, 1000, 1000);
    }
        else{
            l2.setText("");
        }
            
            }
    void visible(){
        t1.setVisible(false);
        bt1.setVisible(false);
        bt2.setVisible(false);
        bt3.setVisible(false);
        bt4.setVisible(false);
        p1.setVisible(false);
        l2.setVisible(false);
        w1.setVisible(false);
        w2.setVisible(false);
        w3.setVisible(false);
        w4.setVisible(false);
        w1.setVisible(true);
        w2.setVisible(true);
        w3.setVisible(true);
        w4.setVisible(true);
        bt6.setVisible(true);
        bt7.setVisible(true);
        l4.setVisible(false);
    }
    void amount(){
        if(question>=Integer.parseInt(y)||m==1){
      if(question==0){
                w4.setText("0");
            }
      else if(question==1){
          w4.setText("5,000");
      }
       else if(question==2){
          w4.setText("10,000");
      }
       else if(question==3){
          w4.setText("20,000");
      }
       else if(question==4){
          w4.setText("40,000");
      }
       else if(question==5){
          w4.setText("80,000");
      }
       else if(question==6){
          w4.setText("1,60,000");
      }
       else if(question==7){
          w4.setText("3,20,000");
      }
       else if(question==8){
          w4.setText("6,40,000");
      }
       else if(question==9){
          w4.setText("12,50,000");
      }
       else if(question==10){
          w4.setText("25,00,000");
      }
       else if(question==11){
          w4.setText("50,00,000");
      }
       else if(question==12){
          w4.setText("1,00,00,000");
      }
      else if(question==13){
          w4.setText("2,00,00,000");
      }
      else if(question==14){
          w4.setText("5,00,00,000");
      }
      
        }
        else{
            w4.setText("0000000000");
        }
      
      
    }
    void SetData(){
                jb5.setSelected(true);
                if(question==0)
		{
                    JOptionPane.showMessageDialog(null,"  QUESTION for  5000");
			t1.setText("Que1: Which one among these is not a datatype");
			bt1.setText(" A:int");bt2.setText(" B:implement");bt3.setText(" C:boolean");bt4.setText(" D:char");	
                   count=0;
                 start();     
                }
		if(question==1)
		{ 
                   
                    tf1.setBackground(new Color(255,194,44));
                    JOptionPane.showMessageDialog(null,"  QUESTION for  10000");
                    count=0;
                 start();
                    bt1.setBackground(Color.blue);
			t1.setText("Que2: Which class is available to all the \n     class automatically");
			bt1.setText(" A:Swing");bt2.setText(" B:Applet");bt3.setText(" C:Object");bt4.setText(" D:ActionEvent");
                
                }
		if(question==2)
		{
                    tf2.setBackground(new Color(255,194,44));
                    JOptionPane.showMessageDialog(null,"  QUESTION for  20000");
                    bt2.setBackground(Color.blue);
			t1.setText("Que3: Which package is directly available\n to our class without importing it");
			bt1.setText(" A:swing");bt2.setText(" B:applet");bt3.setText(" C:net");bt4.setText(" D:lang");
		  count=0;
                 start();
                }
		if(question==3)
		{tf3.setBackground(new Color(255,194,44));
                    JOptionPane.showMessageDialog(null,"  QUESTION for  40000");
                    bt1.setBackground(Color.blue);
			t1.setText("Que4: String class is defined in which package");
			bt1.setText(" A:lang");bt2.setText(" B:Swing");bt3.setText(" C:Applet");bt4.setText(" D:awt");
		  count=0;
                 start();
                }
		if(question==4)
		{tf4.setBackground(new Color(255,194,44));
                    JOptionPane.showMessageDialog(null,"  QUESTION for  80000");
                    bt2.setBackground(Color.blue);
			t1.setText("Que5: Which institute is best for java coaching");
			bt1.setText(" A:Utek");bt2.setText(" B:Aptech");bt3.setText(" C:SSS IT");bt4.setText(" D:jtek");
		  count=0;
                 start();
                }
		if(question==5)
		{tf5.setBackground(new Color(255,194,44));
                    JOptionPane.showMessageDialog(null,"  QUESTION for  160000");
                    bt3.setBackground(Color.blue);
			t1.setText("Que6: Which one among these is not a keyword");
			bt1.setText(" A:class");bt2.setText(" B:int");bt3.setText(" C:get");bt4.setText(" D:if");
		  count=0;
                 start();
                }
		if(question==6)
		{
                    tf6.setBackground(new Color(255,194,44));
                    JOptionPane.showMessageDialog(null,"  QUESTION for  320000");
                    bt3.setBackground(Color.blue);
			t1.setText("Que7: Which one among these is not a class ");
			bt1.setText(" A:Swing");bt2.setText(" B:Actionperformed");bt3.setText(" C:ActionEvent");bt4.setText(" D:Button");
		count=0;
                 start();
                }
		if(question==7)
		{
                    tf7.setBackground(new Color(255,194,44));
                    JOptionPane.showMessageDialog(null,"  QUESTION for  640000");
                    bt3.setBackground(Color.blue);
			t1.setText("Que8: which one among these is not a function of Object class");
			bt1.setText(" A:toString");bt2.setText(" B:finalize");bt3.setText(" C:equals");bt4.setText(" D:getDocumentBase");		
		  count=0;
                 start();
                }
		if(question==8)
		{
                    tf8.setBackground(new Color(255,194,44));
                    JOptionPane.showMessageDialog(null,"  QUESTION for  1250000");
                    bt4.setBackground(Color.blue);
			t1.setText("Que9: which function is not present in Applet class");
			bt1.setText(" A:init");bt2.setText(" B:main");bt3.setText(" C:start");bt4.setText(" D:destroy");
		  count=0;
                 start();
                }
		if(question==9)
		{
                    tf9.setBackground(new Color(255,194,44));
                    JOptionPane.showMessageDialog(null,"  QUESTION for  2500000");
                    bt4.setBackground(Color.blue);
			t1.setText("Que10: Which one among these is not a valid component");
			bt1.setText(" A:JButton");bt2.setText(" B:JList");bt3.setText(" C:JButtonGroup");bt4.setText(" D:JTextArea");
                 count=0;
                 start();
                }
                if(question==10)
		{
                    tf9.setBackground(new Color(255,194,44));
                    JOptionPane.showMessageDialog(null,"  QUESTION for  5000000");
                    bt4.setBackground(Color.blue);
			t1.setText("Que10: Which one among these is not a valid component");
			bt1.setText(" A:JButton");bt2.setText(" B:JList");bt3.setText(" C:JButtonGroup");bt4.setText(" D:JTextArea");
                 count=0;
                 start();
                }
                if(question==11)
		{
                    tf9.setBackground(new Color(255,194,44));
                    JOptionPane.showMessageDialog(null,"  QUESTION for  10000000");
                    bt4.setBackground(Color.blue);
			t1.setText("Que10: Which one among these is not a valid component");
			bt1.setText(" A:JButton");bt2.setText(" B:JList");bt3.setText(" C:JButtonGroup");bt4.setText(" D:JTextArea");
                 count=0;
                 start();
                }
                if(question==12)
		{
                    tf9.setBackground(new Color(255,194,44));
                    JOptionPane.showMessageDialog(null,"  QUESTION for  20000000");
                    bt4.setBackground(Color.blue);
			t1.setText("Que10: Which one among these is not a valid component");
			bt1.setText(" A:JButton");bt2.setText(" B:JList");bt3.setText(" C:JButtonGroup");bt4.setText(" D:JTextArea");
                 count=0;
                 start();
                }
                if(question==13)
		{
                    tf9.setBackground(new Color(255,194,44));
                    JOptionPane.showMessageDialog(null,"  QUESTION for  50000000");
                    bt4.setBackground(Color.blue);
			t1.setText("Que10: Which one among these is not a valid component");
			bt1.setText(" A:JButton");bt2.setText(" B:JList");bt3.setText(" C:JButtonGroup");bt4.setText(" D:JTextArea");
                 count=0;
                 start();
                }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        bg = new javax.swing.ButtonGroup();
        p1 = new javax.swing.JPanel();
        tf1 = new javax.swing.JTextField();
        tf2 = new javax.swing.JTextField();
        tf3 = new javax.swing.JTextField();
        tf4 = new javax.swing.JTextField();
        tf5 = new javax.swing.JTextField();
        tf6 = new javax.swing.JTextField();
        tf7 = new javax.swing.JTextField();
        tf8 = new javax.swing.JTextField();
        tf9 = new javax.swing.JTextField();
        tf11 = new javax.swing.JTextField();
        tf10 = new javax.swing.JTextField();
        tf13 = new javax.swing.JTextField();
        tf12 = new javax.swing.JTextField();
        tf14 = new javax.swing.JTextField();
        play = new javax.swing.JButton();
        instruction = new javax.swing.JButton();
        exit = new javax.swing.JButton();
        bt1 = new javax.swing.JButton();
        bt2 = new javax.swing.JButton();
        bt4 = new javax.swing.JButton();
        bt3 = new javax.swing.JButton();
        t1 = new javax.swing.JLabel();
        l2 = new javax.swing.JLabel();
        w1 = new javax.swing.JTextField();
        w2 = new javax.swing.JTextField();
        w3 = new javax.swing.JTextField();
        w4 = new javax.swing.JTextField();
        l4 = new javax.swing.JLabel();
        bt6 = new javax.swing.JButton();
        bt7 = new javax.swing.JButton();
        bt5 = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        l3 = new javax.swing.JTextField();
        bt9 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        p1.setOpaque(false);

        tf1.setEditable(false);
        tf1.setBackground(new java.awt.Color(0, 204, 0));
        tf1.setFont(new java.awt.Font("Arial", 1, 20)); // NOI18N
        tf1.setForeground(new java.awt.Color(255, 255, 255));
        tf1.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        tf1.setText("5,000");
        tf1.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));

        tf2.setEditable(false);
        tf2.setBackground(new java.awt.Color(0, 204, 0));
        tf2.setFont(new java.awt.Font("Arial", 1, 20)); // NOI18N
        tf2.setForeground(new java.awt.Color(255, 255, 255));
        tf2.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        tf2.setText("10,000");
        tf2.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        tf2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tf2jTextField30jTextField2ActionPerformed(evt);
            }
        });

        tf3.setEditable(false);
        tf3.setBackground(new java.awt.Color(0, 204, 0));
        tf3.setFont(new java.awt.Font("Arial", 1, 20)); // NOI18N
        tf3.setForeground(new java.awt.Color(255, 255, 255));
        tf3.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        tf3.setText("20,000");
        tf3.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        tf3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tf3jTextField31jTextField3ActionPerformed(evt);
            }
        });

        tf4.setEditable(false);
        tf4.setBackground(new java.awt.Color(0, 204, 0));
        tf4.setFont(new java.awt.Font("Arial", 1, 20)); // NOI18N
        tf4.setForeground(new java.awt.Color(255, 255, 255));
        tf4.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        tf4.setText("40,000");
        tf4.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        tf4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tf4jTextField32jTextField4ActionPerformed(evt);
            }
        });

        tf5.setEditable(false);
        tf5.setBackground(new java.awt.Color(0, 204, 0));
        tf5.setFont(new java.awt.Font("Arial", 1, 20)); // NOI18N
        tf5.setForeground(new java.awt.Color(255, 255, 255));
        tf5.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        tf5.setText("80,000");
        tf5.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        tf5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tf5jTextField33jTextField5ActionPerformed(evt);
            }
        });

        tf6.setEditable(false);
        tf6.setBackground(new java.awt.Color(0, 204, 0));
        tf6.setFont(new java.awt.Font("Arial", 1, 20)); // NOI18N
        tf6.setForeground(new java.awt.Color(255, 255, 255));
        tf6.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        tf6.setText("1,60,000");
        tf6.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        tf6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tf6jTextField34jTextField6ActionPerformed(evt);
            }
        });

        tf7.setEditable(false);
        tf7.setBackground(new java.awt.Color(0, 204, 0));
        tf7.setFont(new java.awt.Font("Arial", 1, 20)); // NOI18N
        tf7.setForeground(new java.awt.Color(255, 255, 255));
        tf7.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        tf7.setText("3,20,000");
        tf7.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        tf7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tf7jTextField35jTextField7ActionPerformed(evt);
            }
        });

        tf8.setEditable(false);
        tf8.setBackground(new java.awt.Color(0, 204, 0));
        tf8.setFont(new java.awt.Font("Arial", 1, 20)); // NOI18N
        tf8.setForeground(new java.awt.Color(255, 255, 255));
        tf8.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        tf8.setText("6,40,000");
        tf8.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        tf8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tf8jTextField36jTextField8ActionPerformed(evt);
            }
        });

        tf9.setEditable(false);
        tf9.setBackground(new java.awt.Color(0, 204, 0));
        tf9.setFont(new java.awt.Font("Arial", 1, 20)); // NOI18N
        tf9.setForeground(new java.awt.Color(255, 255, 255));
        tf9.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        tf9.setText("12,50,000");
        tf9.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        tf9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tf9jTextField37jTextField9ActionPerformed(evt);
            }
        });

        tf11.setEditable(false);
        tf11.setBackground(new java.awt.Color(0, 204, 0));
        tf11.setFont(new java.awt.Font("Arial", 1, 20)); // NOI18N
        tf11.setForeground(new java.awt.Color(255, 255, 255));
        tf11.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        tf11.setText("50,00,000");
        tf11.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        tf11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tf11jTextField38jTextField10ActionPerformed(evt);
            }
        });

        tf10.setEditable(false);
        tf10.setBackground(new java.awt.Color(0, 204, 0));
        tf10.setFont(new java.awt.Font("Arial", 1, 20)); // NOI18N
        tf10.setForeground(new java.awt.Color(255, 255, 255));
        tf10.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        tf10.setText("25,00,000");
        tf10.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        tf10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tf10jTextField39jTextField11ActionPerformed(evt);
            }
        });

        tf13.setEditable(false);
        tf13.setBackground(new java.awt.Color(0, 204, 0));
        tf13.setFont(new java.awt.Font("Arial", 1, 20)); // NOI18N
        tf13.setForeground(new java.awt.Color(255, 255, 255));
        tf13.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        tf13.setText("2,00,00,000");
        tf13.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        tf13.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tf13jTextField40jTextField12ActionPerformed(evt);
            }
        });

        tf12.setEditable(false);
        tf12.setBackground(new java.awt.Color(0, 204, 0));
        tf12.setFont(new java.awt.Font("Arial", 1, 20)); // NOI18N
        tf12.setForeground(new java.awt.Color(255, 255, 255));
        tf12.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        tf12.setText("1,00,00,000");
        tf12.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        tf12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tf12jTextField41jTextField13ActionPerformed(evt);
            }
        });

        tf14.setEditable(false);
        tf14.setBackground(new java.awt.Color(0, 204, 0));
        tf14.setFont(new java.awt.Font("Arial", 1, 20)); // NOI18N
        tf14.setForeground(new java.awt.Color(255, 255, 255));
        tf14.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        tf14.setText("5,00,00,000");
        tf14.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        tf14.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tf14jTextField42jTextField14ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout p1Layout = new javax.swing.GroupLayout(p1);
        p1.setLayout(p1Layout);
        p1Layout.setHorizontalGroup(
            p1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(p1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(p1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, p1Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addGroup(p1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, p1Layout.createSequentialGroup()
                                .addGroup(p1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(p1Layout.createSequentialGroup()
                                        .addComponent(tf6, javax.swing.GroupLayout.PREFERRED_SIZE, 183, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(38, 38, 38))
                                    .addGroup(p1Layout.createSequentialGroup()
                                        .addComponent(tf7, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(30, 30, 30))
                                    .addGroup(p1Layout.createSequentialGroup()
                                        .addComponent(tf8, javax.swing.GroupLayout.PREFERRED_SIZE, 216, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(22, 22, 22))
                                    .addGroup(p1Layout.createSequentialGroup()
                                        .addComponent(tf9, javax.swing.GroupLayout.PREFERRED_SIZE, 232, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(14, 14, 14))
                                    .addComponent(tf10, javax.swing.GroupLayout.PREFERRED_SIZE, 254, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(p1Layout.createSequentialGroup()
                                        .addComponent(tf5, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(46, 46, 46))
                                    .addGroup(p1Layout.createSequentialGroup()
                                        .addComponent(tf4, javax.swing.GroupLayout.PREFERRED_SIZE, 147, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(54, 54, 54))
                                    .addGroup(p1Layout.createSequentialGroup()
                                        .addComponent(tf3, javax.swing.GroupLayout.PREFERRED_SIZE, 131, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(62, 62, 62))
                                    .addGroup(p1Layout.createSequentialGroup()
                                        .addComponent(tf2, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(70, 70, 70)))
                                .addGap(35, 35, 35))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, p1Layout.createSequentialGroup()
                                .addComponent(tf11, javax.swing.GroupLayout.PREFERRED_SIZE, 275, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(26, 26, 26))))
                    .addGroup(p1Layout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addComponent(tf12, javax.swing.GroupLayout.PREFERRED_SIZE, 292, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(23, Short.MAX_VALUE))
                    .addGroup(p1Layout.createSequentialGroup()
                        .addComponent(tf13)
                        .addContainerGap())))
            .addComponent(tf14)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, p1Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(tf1, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(115, 115, 115))
        );
        p1Layout.setVerticalGroup(
            p1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, p1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(tf14, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(tf13, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(tf12, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(tf11, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(tf10, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(tf9, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(tf8, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(tf7, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(tf6, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(tf5, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(tf4, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(tf3, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(tf2, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(tf1, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        play.setBackground(new java.awt.Color(9, 6, 109));
        play.setFont(new java.awt.Font("Rockwell", 1, 24)); // NOI18N
        play.setForeground(new java.awt.Color(255, 255, 255));
        play.setText("Play");
        play.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                playActionPerformed(evt);
            }
        });

        instruction.setBackground(new java.awt.Color(9, 6, 109));
        instruction.setFont(new java.awt.Font("Rockwell", 1, 24)); // NOI18N
        instruction.setForeground(new java.awt.Color(255, 255, 255));
        instruction.setText("Instruction");
        instruction.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                instructionActionPerformed(evt);
            }
        });

        exit.setBackground(new java.awt.Color(9, 6, 109));
        exit.setFont(new java.awt.Font("Rockwell", 1, 24)); // NOI18N
        exit.setForeground(new java.awt.Color(255, 255, 255));
        exit.setText("Exit");
        exit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exitActionPerformed(evt);
            }
        });

        bt1.setBackground(java.awt.Color.blue);
        bt1.setFont(new java.awt.Font("Monospaced", 1, 18)); // NOI18N
        bt1.setForeground(new java.awt.Color(255, 255, 255));
        bt1.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        bt1.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        bt1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bt1ActionPerformed(evt);
            }
        });

        bt2.setBackground(java.awt.Color.blue);
        bt2.setFont(new java.awt.Font("Monospaced", 1, 18)); // NOI18N
        bt2.setForeground(new java.awt.Color(255, 255, 255));
        bt2.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        bt2.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        bt2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bt2ActionPerformed(evt);
            }
        });

        bt4.setBackground(java.awt.Color.blue);
        bt4.setFont(new java.awt.Font("Monospaced", 1, 18)); // NOI18N
        bt4.setForeground(new java.awt.Color(255, 255, 255));
        bt4.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        bt4.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        bt4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bt4ActionPerformed(evt);
            }
        });

        bt3.setBackground(java.awt.Color.blue);
        bt3.setFont(new java.awt.Font("Monospaced", 1, 18)); // NOI18N
        bt3.setForeground(new java.awt.Color(255, 255, 255));
        bt3.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        bt3.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        bt3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bt3ActionPerformed(evt);
            }
        });

        t1.setBackground(new java.awt.Color(255, 255, 255));
        t1.setFont(new java.awt.Font("Adobe Caslon Pro", 1, 26)); // NOI18N
        t1.setForeground(new java.awt.Color(255, 255, 255));
        t1.setVerticalAlignment(javax.swing.SwingConstants.TOP);

        l2.setFont(new java.awt.Font("Trajan Pro", 1, 160)); // NOI18N
        l2.setForeground(new java.awt.Color(204, 204, 204));
        l2.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        l2.setText("20");
        l2.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        l2.setAlignmentY(0.0F);

        w1.setEditable(false);
        w1.setBackground(new java.awt.Color(255, 204, 102));
        w1.setFont(new java.awt.Font("Lucida Calligraphy", 1, 80)); // NOI18N
        w1.setForeground(new java.awt.Color(255, 255, 255));
        w1.setText("COGRATULATIONS");
        w1.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 204, 51), 5, true));
        w1.setOpaque(false);

        w2.setEditable(false);
        w2.setBackground(new java.awt.Color(255, 153, 51));
        w2.setFont(new java.awt.Font("Tahoma", 1, 80)); // NOI18N
        w2.setForeground(new java.awt.Color(255, 255, 255));
        w2.setText("You Earn");
        w2.setBorder(null);
        w2.setOpaque(false);

        w3.setEditable(false);
        w3.setBackground(new java.awt.Color(255, 153, 51));
        w3.setFont(new java.awt.Font("Tahoma", 0, 80)); // NOI18N
        w3.setForeground(new java.awt.Color(255, 255, 255));
        w3.setText("Rs.");
        w3.setBorder(null);
        w3.setOpaque(false);

        w4.setEditable(false);
        w4.setBackground(new java.awt.Color(255, 153, 51));
        w4.setFont(new java.awt.Font("Tahoma", 1, 80)); // NOI18N
        w4.setForeground(new java.awt.Color(255, 255, 255));
        w4.setBorder(null);
        w4.setOpaque(false);

        l4.setFont(new java.awt.Font("Tahoma", 0, 275)); // NOI18N
        l4.setForeground(new java.awt.Color(255, 0, 0));
        l4.setText("Time Up!!!");

        bt6.setFont(new java.awt.Font("Tahoma", 1, 30)); // NOI18N
        bt6.setText("Home");
        bt6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bt6ActionPerformed(evt);
            }
        });

        bt7.setFont(new java.awt.Font("Times New Roman", 1, 30)); // NOI18N
        bt7.setText("Exit!!");
        bt7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bt7ActionPerformed(evt);
            }
        });

        bt5.setFont(new java.awt.Font("Tekton Pro Cond", 0, 100)); // NOI18N
        bt5.setText("Set Boundary");
        bt5.setAlignmentY(0.0F);
        bt5.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        bt5.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        bt5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bt5ActionPerformed(evt);
            }
        });

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/kbc/icon/kbc.png"))); // NOI18N
        jLabel2.setText("jLabel2");

        l3.setBackground(new java.awt.Color(204, 255, 204));
        l3.setFont(new java.awt.Font("Times New Roman", 1, 110)); // NOI18N
        l3.setText("0");
        l3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                l3ActionPerformed(evt);
            }
        });

        bt9.setFont(new java.awt.Font("Times New Roman", 1, 36)); // NOI18N
        bt9.setForeground(new java.awt.Color(255, 51, 51));
        bt9.setText("Quit");
        bt9.setOpaque(false);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(451, 451, 451)
                                .addComponent(play, javax.swing.GroupLayout.PREFERRED_SIZE, 149, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(177, 177, 177)
                                .addComponent(instruction)
                                .addGap(390, 390, 390)
                                .addComponent(exit, javax.swing.GroupLayout.PREFERRED_SIZE, 165, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(64, 64, 64)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                        .addComponent(bt2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addGap(190, 190, 190)
                                        .addComponent(bt4, javax.swing.GroupLayout.PREFERRED_SIZE, 364, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(bt1, javax.swing.GroupLayout.PREFERRED_SIZE, 334, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(190, 190, 190)
                                        .addComponent(bt3, javax.swing.GroupLayout.PREFERRED_SIZE, 364, javax.swing.GroupLayout.PREFERRED_SIZE))))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(308, 308, 308)
                                .addComponent(l2)))
                        .addGap(18, 18, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(l3, javax.swing.GroupLayout.PREFERRED_SIZE, 112, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(379, 379, 379)))
                .addComponent(p1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(26, 26, 26))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                    .addContainerGap(105, Short.MAX_VALUE)
                    .addComponent(t1, javax.swing.GroupLayout.PREFERRED_SIZE, 831, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(395, Short.MAX_VALUE)))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                    .addContainerGap(173, Short.MAX_VALUE)
                    .addComponent(w1, javax.swing.GroupLayout.PREFERRED_SIZE, 963, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(195, Short.MAX_VALUE)))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                    .addContainerGap(474, Short.MAX_VALUE)
                    .addComponent(w2, javax.swing.GroupLayout.PREFERRED_SIZE, 365, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(492, Short.MAX_VALUE)))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                    .addContainerGap(367, Short.MAX_VALUE)
                    .addComponent(w3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(854, Short.MAX_VALUE)))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                    .addContainerGap(479, Short.MAX_VALUE)
                    .addComponent(w4, javax.swing.GroupLayout.PREFERRED_SIZE, 468, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(384, Short.MAX_VALUE)))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                    .addContainerGap(23, Short.MAX_VALUE)
                    .addComponent(l4, javax.swing.GroupLayout.PREFERRED_SIZE, 1276, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(32, Short.MAX_VALUE)))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                    .addContainerGap(310, Short.MAX_VALUE)
                    .addComponent(bt6, javax.swing.GroupLayout.PREFERRED_SIZE, 165, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(856, Short.MAX_VALUE)))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                    .addContainerGap(819, Short.MAX_VALUE)
                    .addComponent(bt7, javax.swing.GroupLayout.PREFERRED_SIZE, 172, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(340, Short.MAX_VALUE)))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                    .addContainerGap(376, Short.MAX_VALUE)
                    .addComponent(bt5, javax.swing.GroupLayout.PREFERRED_SIZE, 509, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(446, Short.MAX_VALUE)))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                    .addContainerGap(1154, Short.MAX_VALUE)
                    .addComponent(bt9, javax.swing.GroupLayout.PREFERRED_SIZE, 138, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(39, Short.MAX_VALUE)))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(jLabel2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 1331, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(68, 68, 68)
                .addComponent(p1, javax.swing.GroupLayout.PREFERRED_SIZE, 499, Short.MAX_VALUE)
                .addGap(79, 79, 79))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(32, 32, 32)
                .addComponent(l3, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(31, 31, 31)
                .addComponent(l2, javax.swing.GroupLayout.PREFERRED_SIZE, 136, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 62, Short.MAX_VALUE)
                .addComponent(play, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(42, 42, 42)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(bt1, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 3, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(bt3, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(exit, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(bt2, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(bt4, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(instruction))
                .addGap(59, 59, 59))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                    .addContainerGap(397, Short.MAX_VALUE)
                    .addComponent(t1, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(170, Short.MAX_VALUE)))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                    .addContainerGap(60, Short.MAX_VALUE)
                    .addComponent(w1, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(478, Short.MAX_VALUE)))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                    .addContainerGap(166, Short.MAX_VALUE)
                    .addComponent(w2, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(369, Short.MAX_VALUE)))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                    .addContainerGap(276, Short.MAX_VALUE)
                    .addComponent(w3, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(292, Short.MAX_VALUE)))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                    .addContainerGap(276, Short.MAX_VALUE)
                    .addComponent(w4, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(293, Short.MAX_VALUE)))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                    .addContainerGap(126, Short.MAX_VALUE)
                    .addComponent(l4, javax.swing.GroupLayout.PREFERRED_SIZE, 303, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(217, Short.MAX_VALUE)))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                    .addContainerGap(492, Short.MAX_VALUE)
                    .addComponent(bt6, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(99, Short.MAX_VALUE)))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                    .addContainerGap(491, Short.MAX_VALUE)
                    .addComponent(bt7)
                    .addContainerGap(110, Short.MAX_VALUE)))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                    .addContainerGap(431, Short.MAX_VALUE)
                    .addComponent(bt5, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(115, Short.MAX_VALUE)))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                    .addContainerGap(594, Short.MAX_VALUE)
                    .addComponent(bt9, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap()))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(jLabel2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 646, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void tf2jTextField30jTextField2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tf2jTextField30jTextField2ActionPerformed

    }//GEN-LAST:event_tf2jTextField30jTextField2ActionPerformed

    private void tf3jTextField31jTextField3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tf3jTextField31jTextField3ActionPerformed

    }//GEN-LAST:event_tf3jTextField31jTextField3ActionPerformed

    private void tf4jTextField32jTextField4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tf4jTextField32jTextField4ActionPerformed

    }//GEN-LAST:event_tf4jTextField32jTextField4ActionPerformed

    private void tf5jTextField33jTextField5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tf5jTextField33jTextField5ActionPerformed

    }//GEN-LAST:event_tf5jTextField33jTextField5ActionPerformed

    private void tf6jTextField34jTextField6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tf6jTextField34jTextField6ActionPerformed

    }//GEN-LAST:event_tf6jTextField34jTextField6ActionPerformed

    private void tf7jTextField35jTextField7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tf7jTextField35jTextField7ActionPerformed

    }//GEN-LAST:event_tf7jTextField35jTextField7ActionPerformed

    private void tf8jTextField36jTextField8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tf8jTextField36jTextField8ActionPerformed

    }//GEN-LAST:event_tf8jTextField36jTextField8ActionPerformed

    private void tf9jTextField37jTextField9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tf9jTextField37jTextField9ActionPerformed

    }//GEN-LAST:event_tf9jTextField37jTextField9ActionPerformed

    private void tf11jTextField38jTextField10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tf11jTextField38jTextField10ActionPerformed

    }//GEN-LAST:event_tf11jTextField38jTextField10ActionPerformed

    private void tf10jTextField39jTextField11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tf10jTextField39jTextField11ActionPerformed

    }//GEN-LAST:event_tf10jTextField39jTextField11ActionPerformed

    private void tf13jTextField40jTextField12ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tf13jTextField40jTextField12ActionPerformed

    }//GEN-LAST:event_tf13jTextField40jTextField12ActionPerformed

    private void tf12jTextField41jTextField13ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tf12jTextField41jTextField13ActionPerformed

    }//GEN-LAST:event_tf12jTextField41jTextField13ActionPerformed

    private void tf14jTextField42jTextField14ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tf14jTextField42jTextField14ActionPerformed

    }//GEN-LAST:event_tf14jTextField42jTextField14ActionPerformed

    private void playActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_playActionPerformed

        l3.setVisible(true);
        bt5.setVisible(true);
        play.setVisible(false);
        exit.setVisible(false);
        instruction.setVisible(false);
        
    }//GEN-LAST:event_playActionPerformed

    private void instructionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_instructionActionPerformed

    }//GEN-LAST:event_instructionActionPerformed

    private void exitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exitActionPerformed
        System.exit(0);
    }//GEN-LAST:event_exitActionPerformed

    private void bt1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bt1ActionPerformed
        if(question==0||question==2||question==10||question==12){
         // TODO add your handling code here:
              count=1;
                bt1.setBackground(Color.green);
                l2.setForeground(Color.LIGHT_GRAY);
                question++;
                SetData();
        }
        else{
            bt1.setBackground(Color.red);
            count=1;
              l2.setForeground(Color.RED);
            JOptionPane.showMessageDialog(null,"Wrong ans");
             visible();
             amount();
            
        }
    }//GEN-LAST:event_bt1ActionPerformed

    private void bt2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bt2ActionPerformed
        if(question==1||question==3||question==11){
                count=1;
                bt2.setBackground(Color.green);
                l2.setForeground(Color.LIGHT_GRAY);
                question++;
                SetData();
        }
        else{
            bt2.setBackground(Color.red);
            count=1;
              l2.setForeground(Color.RED);
            JOptionPane.showMessageDialog(null,"Wrong ans");
            visible();
             amount();
        }
    }//GEN-LAST:event_bt2ActionPerformed

    private void bt4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bt4ActionPerformed
        if(question==7||question==8||question==9){   // TODO add your handling code here:
            count=1; 
                bt4.setBackground(Color.green);
                question++;
                SetData();
                l2.setForeground(Color.LIGHT_GRAY);        
        }
        else{
            bt4.setBackground(Color.red);
            count=1;
              l2.setForeground(Color.RED);
            JOptionPane.showMessageDialog(null,"Wrong ans");
            visible();
             amount();
        }
    }//GEN-LAST:event_bt4ActionPerformed

    private void bt3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bt3ActionPerformed
        if(question==5||question==6||question==4||question==13){
            
                        if(question==13){
                            JOptionPane.showMessageDialog(null,".....EXCELLENT......");
                         visible();
                         amount();
                        }   
            count=1;
                bt3.setBackground(Color.green);
                question++;
                SetData();
                l2.setForeground(Color.LIGHT_GRAY);
                
        }
        else{
            bt3.setBackground(Color.red);
            count=1;
              l2.setForeground(Color.RED);
            JOptionPane.showMessageDialog(null,"Wrong ans");
            visible();
             amount();
        }       // TODO add your handling code here:
    }//GEN-LAST:event_bt3ActionPerformed

    private void bt7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bt7ActionPerformed
System.exit(0);        // TODO add your handling code here:
    }//GEN-LAST:event_bt7ActionPerformed

    private void bt6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bt6ActionPerformed
play.setVisible(true);
instruction.setVisible(true);
exit.setVisible(true);
bt6.setVisible(false);
bt7.setVisible(false);
        bt5.setVisible(false);
        w2.setVisible(false);
        w3.setVisible(false);
        w4.setVisible(false);
        w1.setVisible(false);
bt9.setVisible(false);// TODO add your handling code here:
    }//GEN-LAST:event_bt6ActionPerformed

    private void bt5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bt5ActionPerformed
        y=l3.getText();
        l3.setVisible(false);
        bt5.setVisible(false);
        play.setVisible(false);
        exit.setVisible(false);
        instruction.setVisible(false);
        t1.setVisible(true);
        bt1.setVisible(true);
        bt2.setVisible(true);
        bt3.setVisible(true);
        bt4.setVisible(true);
        p1.setVisible(true);
        l2.setVisible(true);
        bt9.setVisible(true);
        SetData();        // TODO add your handling code here:
    }//GEN-LAST:event_bt5ActionPerformed

    private void l3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_l3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_l3ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
       
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Kbc4.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Kbc4.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Kbc4.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Kbc4.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Kbc4().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.ButtonGroup bg;
    private javax.swing.JButton bt1;
    private javax.swing.JButton bt2;
    private javax.swing.JButton bt3;
    private javax.swing.JButton bt4;
    private javax.swing.JButton bt5;
    private javax.swing.JButton bt6;
    private javax.swing.JButton bt7;
    private javax.swing.JButton bt9;
    private javax.swing.JButton exit;
    private javax.swing.JButton instruction;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel l2;
    private javax.swing.JTextField l3;
    private javax.swing.JLabel l4;
    private javax.swing.JPanel p1;
    private javax.swing.JButton play;
    private javax.swing.JLabel t1;
    private javax.swing.JTextField tf1;
    private javax.swing.JTextField tf10;
    private javax.swing.JTextField tf11;
    private javax.swing.JTextField tf12;
    private javax.swing.JTextField tf13;
    private javax.swing.JTextField tf14;
    private javax.swing.JTextField tf2;
    private javax.swing.JTextField tf3;
    private javax.swing.JTextField tf4;
    private javax.swing.JTextField tf5;
    private javax.swing.JTextField tf6;
    private javax.swing.JTextField tf7;
    private javax.swing.JTextField tf8;
    private javax.swing.JTextField tf9;
    private javax.swing.JTextField w1;
    private javax.swing.JTextField w2;
    private javax.swing.JTextField w3;
    private javax.swing.JTextField w4;
    // End of variables declaration//GEN-END:variables
}
