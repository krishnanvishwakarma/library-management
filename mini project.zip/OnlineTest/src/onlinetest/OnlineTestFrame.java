/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package onlinetest;

import java.awt.Color;
import java.util.Timer;
import java.util.TimerTask;
import javax.swing.ButtonGroup;
import javax.swing.JOptionPane;
import javax.swing.JRadioButton;

/**
 *
 * @author ADARSH
 */
public class OnlineTestFrame extends javax.swing.JFrame {
    int question=0;
    int count=0,q1,q2,q3,q4,q5,q6,q7,q8,q9,q0,counter;
    JRadioButton jb5=new JRadioButton();

    /**
     * Creates new form OnlineTestFrame
     */
    public OnlineTestFrame() {
        initComponents();
        
      bg.add(jb1);
      bg.add(jb2);
      bg.add(jb3);
      bg.add(jb4);
      bg.add(jb5);
      SetData();
      start();
    }
    void start(){      
        
            
       Timer timer = new Timer(); 
         counter=600; 
                            TimerTask task = new TimerTask() {         
                               public void run() {                
                            l2.setText(Integer.toString(counter)); //the timer lable to counter.
                            counter --;
                            
                              } };
                            timer.scheduleAtFixedRate(task, 1000, 1000);
    }
            
   
    void SetData(){
        jb5.setSelected(true);
                if(question==0)
		{
			tf.setText("Que1: Which one among these is not a datatype");
			jb1.setText("int");jb2.setText("Float");jb3.setText("boolean");jb4.setText("char");	
		}
		if(question==1)
		{
			tf.setText("Que2: Which class is available to all the \n     class automatically");
			jb1.setText("Swing");jb2.setText("Applet");jb3.setText("Object");jb4.setText("ActionEvent");
		}
		if(question==2)
		{
			tf.setText("Que3: Which package is directly available\n to our class without importing it");
			jb1.setText("swing");jb2.setText("applet");jb3.setText("net");jb4.setText("lang");
		}
		if(question==3)
		{
			tf.setText("Que4: String class is defined in which package");
			jb1.setText("lang");jb2.setText("Swing");jb3.setText("Applet");jb4.setText("awt");
		}
		if(question==4)
		{
			tf.setText("Que5: Which institute is best for java coaching");
			jb1.setText("Utek");jb2.setText("Aptech");jb3.setText("SSS IT");jb4.setText("jtek");
		}
		if(question==5)
		{
			tf.setText("Que6: Which one among these is not a keyword");
			jb1.setText("class");jb2.setText("int");jb3.setText("get");jb4.setText("if");
		}
		if(question==6)
		{
			tf.setText("Que7: Which one among these is not a class ");
			jb1.setText("Swing");jb2.setText("Actionperformed");jb3.setText("ActionEvent");jb4.setText("Button");
		}
		if(question==7)
		{
			tf.setText("Que8: which one among these is not a function of Object class");
			jb1.setText("toString");jb2.setText("finalize");jb3.setText("equals");jb4.setText("getDocumentBase");		
		}
		if(question==8)
		{
			tf.setText("Que9: which function is not present in Applet class");
			jb1.setText("init");jb2.setText("main");jb3.setText("start");jb4.setText("destroy");
		}
		if(question==9)
		{
			tf.setText("Que10: Which one among these is not a valid component");
			jb1.setText("JButton");jb2.setText("JList");jb3.setText("JButtonGroup");jb4.setText("JTextArea");
                }
    }
    void check(){
        
        if(question==0){
            if(jb1.isSelected()){
            count++;
            q1=1;
            
            }
            else if(jb2.isSelected()){
            
            q1=2;
            
            }
            else  if(jb3.isSelected()){
            
            q1=3;
            
            }
           else if(jb4.isSelected()){
            
            q1=4;
            
            }
            if(jb1.isSelected()||jb2.isSelected()||jb3.isSelected()||jb4.isSelected()){
           bt1.setBackground(Color.GREEN);
            }
            if(q1==1){
                jb1.setSelected(true);
            }
            else if(q1==2){
                jb2.setSelected(true);
            }
             else if(q1==3){
                jb3.setSelected(true);
            }
             else if(q1==4){
                jb4.setSelected(true);
            }
            
        }
        if(question==1){
              if(jb1.isSelected()){
            count++;
            q2=1;
            
            }
            else if(jb2.isSelected()){
            
            q2=2;
            
            }
            else  if(jb3.isSelected()){
            
            q2=3;
            
            }
           else if(jb4.isSelected()){
            
            q2=4;
            
            }
            if(jb1.isSelected()||jb2.isSelected()||jb3.isSelected()||jb4.isSelected()){
           bt2.setBackground(Color.GREEN);
            }
            if(q2==1){
                jb1.setSelected(true);
            }
            else if(q2==2){
                jb2.setSelected(true);
            }
             else if(q2==3){
                jb3.setSelected(true);
            }
             else if(q2==4){
                jb4.setSelected(true);
            }           
        }
        if(question==2){
               if(jb1.isSelected()){
            count++;
            q3=1;
            
            }
            else if(jb2.isSelected()){
            
            q3=2;
            
            }
            else  if(jb3.isSelected()){
            
            q3=3;
            
            }
           else if(jb4.isSelected()){
            
            q3=4;
            
            }
            if(jb3.isSelected()||jb2.isSelected()||jb3.isSelected()||jb4.isSelected()){
           bt1.setBackground(Color.GREEN);
            }
            if(q3==1){
                jb1.setSelected(true);
            }
            else if(q3==2){
                jb2.setSelected(true);
            }
             else if(q3==3){
                jb3.setSelected(true);
            }
             else if(q3==4){
                jb4.setSelected(true);
            }        
        }
        if(question==3){
                    if(jb1.isSelected()){
            count++;
            }
             if(jb1.isSelected()||jb2.isSelected()||jb3.isSelected()||jb4.isSelected()){
           bt4.setBackground(Color.GREEN);
            }            
        }
        if(question==4){
                   if(jb1.isSelected()){
            count++;
            }
          if(jb1.isSelected()||jb2.isSelected()||jb3.isSelected()||jb4.isSelected()){
           bt5.setBackground(Color.GREEN);
            }         
        }
        if(question==5){
                    if(jb1.isSelected()){
            count++;
            }
          if(jb1.isSelected()||jb2.isSelected()||jb3.isSelected()||jb4.isSelected()){
           bt6.setBackground(Color.GREEN);
            }           
        }
        if(question==6){
                   if(jb1.isSelected()){
            count++;
            }
          if(jb1.isSelected()||jb2.isSelected()||jb3.isSelected()||jb4.isSelected()){
           bt7.setBackground(Color.GREEN);
            }          
        }
        if(question==7){
                    if(jb1.isSelected()){
            count++;
            }
          if(jb1.isSelected()||jb2.isSelected()||jb3.isSelected()||jb4.isSelected()){
           bt8.setBackground(Color.GREEN);
            }       
        }
        if(question==8){
                   if(jb1.isSelected()){
            count++;
            }
          if(jb1.isSelected()||jb2.isSelected()||jb3.isSelected()||jb4.isSelected()){
           bt1.setBackground(Color.GREEN);
            }          
        }
        if(question==9){
                    if(jb1.isSelected()){
            count++;
            }
         if(jb1.isSelected()||jb2.isSelected()||jb3.isSelected()||jb4.isSelected()){
           bt10.setBackground(Color.GREEN);
            }          
        }   
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        bg = new javax.swing.ButtonGroup();
        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        bt1 = new javax.swing.JButton();
        bt2 = new javax.swing.JButton();
        bt4 = new javax.swing.JButton();
        bt3 = new javax.swing.JButton();
        bt5 = new javax.swing.JButton();
        bt6 = new javax.swing.JButton();
        bt7 = new javax.swing.JButton();
        bt8 = new javax.swing.JButton();
        bt9 = new javax.swing.JButton();
        bt10 = new javax.swing.JButton();
        jb1 = new javax.swing.JRadioButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tf = new javax.swing.JTextArea();
        jb2 = new javax.swing.JRadioButton();
        jb3 = new javax.swing.JRadioButton();
        jb4 = new javax.swing.JRadioButton();
        next = new javax.swing.JButton();
        back = new javax.swing.JButton();
        clear = new javax.swing.JButton();
        submit = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        l2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(204, 255, 255));

        jPanel2.setBackground(new java.awt.Color(204, 204, 255));
        jPanel2.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.LOWERED, new java.awt.Color(51, 204, 0), new java.awt.Color(204, 255, 102), new java.awt.Color(51, 255, 51), new java.awt.Color(102, 153, 255)));

        bt1.setBackground(new java.awt.Color(255, 0, 51));
        bt1.setFont(new java.awt.Font("Tahoma", 1, 22)); // NOI18N
        bt1.setForeground(new java.awt.Color(153, 0, 204));
        bt1.setText("1");
        bt1.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        bt1.setBorderPainted(false);
        bt1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bt1ActionPerformed(evt);
            }
        });

        bt2.setBackground(new java.awt.Color(255, 0, 51));
        bt2.setFont(new java.awt.Font("Tahoma", 1, 22)); // NOI18N
        bt2.setForeground(new java.awt.Color(153, 0, 204));
        bt2.setText("2");
        bt2.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        bt2.setBorderPainted(false);
        bt2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bt2ActionPerformed(evt);
            }
        });

        bt4.setBackground(new java.awt.Color(255, 0, 51));
        bt4.setFont(new java.awt.Font("Tahoma", 1, 22)); // NOI18N
        bt4.setForeground(new java.awt.Color(153, 0, 204));
        bt4.setText("4");
        bt4.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        bt4.setBorderPainted(false);
        bt4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bt4ActionPerformed(evt);
            }
        });

        bt3.setBackground(new java.awt.Color(255, 0, 51));
        bt3.setFont(new java.awt.Font("Tahoma", 1, 22)); // NOI18N
        bt3.setForeground(new java.awt.Color(153, 0, 204));
        bt3.setText("3");
        bt3.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        bt3.setBorderPainted(false);
        bt3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bt3ActionPerformed(evt);
            }
        });

        bt5.setBackground(new java.awt.Color(255, 0, 51));
        bt5.setFont(new java.awt.Font("Tahoma", 1, 22)); // NOI18N
        bt5.setForeground(new java.awt.Color(153, 0, 204));
        bt5.setText("5");
        bt5.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        bt5.setBorderPainted(false);
        bt5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bt5ActionPerformed(evt);
            }
        });

        bt6.setBackground(new java.awt.Color(255, 0, 51));
        bt6.setFont(new java.awt.Font("Tahoma", 1, 22)); // NOI18N
        bt6.setForeground(new java.awt.Color(153, 0, 204));
        bt6.setText("6");
        bt6.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        bt6.setBorderPainted(false);
        bt6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bt6ActionPerformed(evt);
            }
        });

        bt7.setBackground(new java.awt.Color(255, 0, 51));
        bt7.setFont(new java.awt.Font("Tahoma", 1, 22)); // NOI18N
        bt7.setForeground(new java.awt.Color(153, 0, 204));
        bt7.setText("7");
        bt7.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        bt7.setBorderPainted(false);
        bt7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bt7ActionPerformed(evt);
            }
        });

        bt8.setBackground(new java.awt.Color(255, 0, 51));
        bt8.setFont(new java.awt.Font("Tahoma", 1, 22)); // NOI18N
        bt8.setForeground(new java.awt.Color(153, 0, 204));
        bt8.setText("8");
        bt8.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        bt8.setBorderPainted(false);
        bt8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bt8ActionPerformed(evt);
            }
        });

        bt9.setBackground(new java.awt.Color(255, 0, 51));
        bt9.setFont(new java.awt.Font("Tahoma", 1, 22)); // NOI18N
        bt9.setForeground(new java.awt.Color(153, 0, 204));
        bt9.setText("9");
        bt9.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        bt9.setBorderPainted(false);
        bt9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bt9ActionPerformed(evt);
            }
        });

        bt10.setBackground(new java.awt.Color(255, 0, 51));
        bt10.setFont(new java.awt.Font("Tahoma", 1, 22)); // NOI18N
        bt10.setForeground(new java.awt.Color(153, 0, 204));
        bt10.setText("10");
        bt10.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        bt10.setBorderPainted(false);
        bt10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bt10ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(51, 51, 51)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(bt3, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(bt4, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addComponent(bt1, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 70, Short.MAX_VALUE)
                        .addComponent(bt2, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, 0))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(bt5, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(bt6, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(bt7, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(bt8, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(bt9, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(bt10, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(39, 39, 39))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(43, 43, 43)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(bt1, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(bt2, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(bt3, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(bt4, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(44, 44, 44)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(bt5, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(bt6, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(35, 35, 35)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(bt7, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(bt8, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(bt9, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(bt10, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(36, 36, 36))
        );

        jb1.setFont(new java.awt.Font("Verdana", 1, 18)); // NOI18N
        jb1.setAlignmentY(0.0F);
        jb1.setAutoscrolls(true);
        jb1.setContentAreaFilled(false);
        jb1.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        jb1.setIconTextGap(10);

        tf.setEditable(false);
        tf.setBackground(new java.awt.Color(204, 255, 255));
        tf.setColumns(20);
        tf.setFont(new java.awt.Font("Monospaced", 1, 16)); // NOI18N
        tf.setRows(5);
        tf.setAlignmentX(0.0F);
        tf.setAlignmentY(0.0F);
        tf.setBorder(null);
        jScrollPane1.setViewportView(tf);

        jb2.setFont(new java.awt.Font("Verdana", 1, 18)); // NOI18N
        jb2.setAlignmentY(0.0F);
        jb2.setAutoscrolls(true);
        jb2.setContentAreaFilled(false);
        jb2.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        jb2.setIconTextGap(10);

        jb3.setFont(new java.awt.Font("Verdana", 1, 18)); // NOI18N
        jb3.setAlignmentY(0.0F);
        jb3.setAutoscrolls(true);
        jb3.setContentAreaFilled(false);
        jb3.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        jb3.setIconTextGap(10);

        jb4.setFont(new java.awt.Font("Verdana", 1, 18)); // NOI18N
        jb4.setAlignmentY(0.0F);
        jb4.setAutoscrolls(true);
        jb4.setContentAreaFilled(false);
        jb4.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        jb4.setIconTextGap(10);

        next.setBackground(new java.awt.Color(51, 255, 51));
        next.setFont(new java.awt.Font("Lucida Fax", 1, 14)); // NOI18N
        next.setText("NEXT");
        next.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nextActionPerformed(evt);
            }
        });

        back.setBackground(new java.awt.Color(51, 255, 51));
        back.setFont(new java.awt.Font("Lucida Fax", 1, 14)); // NOI18N
        back.setText("BACK");
        back.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backActionPerformed(evt);
            }
        });

        clear.setBackground(new java.awt.Color(153, 153, 255));
        clear.setFont(new java.awt.Font("Lucida Fax", 1, 14)); // NOI18N
        clear.setText("CLEAR");
        clear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                clearActionPerformed(evt);
            }
        });

        submit.setBackground(new java.awt.Color(255, 51, 51));
        submit.setFont(new java.awt.Font("Lucida Fax", 1, 14)); // NOI18N
        submit.setForeground(new java.awt.Color(51, 0, 51));
        submit.setText("SUBMIT");
        submit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                submitActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Adobe Caslon Pro", 1, 48)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 153, 102));
        jLabel1.setText("                 JAVA___SUMMER___TRAINING");

        l2.setFont(new java.awt.Font("Times New Roman", 1, 48)); // NOI18N
        l2.setText("00");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(76, 76, 76)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 576, Short.MAX_VALUE)
                        .addGap(186, 186, 186))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(15, 15, 15)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jb2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jb4, javax.swing.GroupLayout.DEFAULT_SIZE, 747, Short.MAX_VALUE)
                            .addComponent(jb3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jb1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addGap(187, 187, 187)
                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(39, 39, 39))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(51, 51, 51)
                .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, 945, Short.MAX_VALUE)
                .addGap(342, 342, 342))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(267, 267, 267)
                .addComponent(back, javax.swing.GroupLayout.DEFAULT_SIZE, 105, Short.MAX_VALUE)
                .addGap(66, 66, 66)
                .addComponent(clear, javax.swing.GroupLayout.DEFAULT_SIZE, 107, Short.MAX_VALUE)
                .addGap(76, 76, 76)
                .addComponent(next, javax.swing.GroupLayout.DEFAULT_SIZE, 106, Short.MAX_VALUE)
                .addGap(76, 76, 76)
                .addComponent(submit, javax.swing.GroupLayout.DEFAULT_SIZE, 105, Short.MAX_VALUE)
                .addGap(430, 430, 430))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(l2, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(129, 129, 129))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(l2, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(30, 30, 30)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(60, 60, 60))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(16, 16, 16)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 127, Short.MAX_VALUE)
                        .addGap(54, 54, 54)
                        .addComponent(jb1, javax.swing.GroupLayout.DEFAULT_SIZE, 52, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jb2, javax.swing.GroupLayout.DEFAULT_SIZE, 57, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jb3, javax.swing.GroupLayout.DEFAULT_SIZE, 52, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jb4, javax.swing.GroupLayout.DEFAULT_SIZE, 57, Short.MAX_VALUE)
                        .addGap(34, 34, 34)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(next, javax.swing.GroupLayout.DEFAULT_SIZE, 35, Short.MAX_VALUE)
                            .addComponent(back, javax.swing.GroupLayout.DEFAULT_SIZE, 35, Short.MAX_VALUE)
                            .addComponent(clear, javax.swing.GroupLayout.DEFAULT_SIZE, 35, Short.MAX_VALUE)
                            .addComponent(submit, javax.swing.GroupLayout.DEFAULT_SIZE, 35, Short.MAX_VALUE))
                        .addGap(19, 19, 19))))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void clearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_clearActionPerformed
jb1.setSelected(false);
jb2.setSelected(false);
jb3.setSelected(false);
jb4.setSelected(false);
    }//GEN-LAST:event_clearActionPerformed

    private void nextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nextActionPerformed
	
         check();
        question++;
        SetData();
       
				
			    
    }//GEN-LAST:event_nextActionPerformed

    private void submitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_submitActionPerformed

    check();
    JOptionPane.showMessageDialog(null,"Your score is:"+count);     
        System.exit(0);

        JOptionPane.showMessageDialog(null,"Your score is:"+count);     
        System.exit(0);
    }//GEN-LAST:event_submitActionPerformed

    private void bt1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bt1ActionPerformed

        question=0;
        SetData();
check();
    }//GEN-LAST:event_bt1ActionPerformed

    private void bt2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bt2ActionPerformed

        question=1;
        SetData();  
        check();
    }//GEN-LAST:event_bt2ActionPerformed

    private void bt3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bt3ActionPerformed
question=2;
        SetData();
check();        
    }//GEN-LAST:event_bt3ActionPerformed

    private void bt4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bt4ActionPerformed
question=3;
        SetData();
check();        
    }//GEN-LAST:event_bt4ActionPerformed

    private void bt5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bt5ActionPerformed
question=4;
        SetData();
check();        
    }//GEN-LAST:event_bt5ActionPerformed

    private void bt6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bt6ActionPerformed
question=5;
        SetData();
check();        
    }//GEN-LAST:event_bt6ActionPerformed

    private void bt7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bt7ActionPerformed
question=6;
        SetData();
check();        
    }//GEN-LAST:event_bt7ActionPerformed

    private void bt8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bt8ActionPerformed
     question=7;
        SetData();
        check();
    }//GEN-LAST:event_bt8ActionPerformed

    private void bt9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bt9ActionPerformed
        question=8;
        SetData();
check();
    }//GEN-LAST:event_bt9ActionPerformed

    private void bt10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bt10ActionPerformed
        question=9;
        SetData();
check();
    }//GEN-LAST:event_bt10ActionPerformed

    private void backActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backActionPerformed
        
        question--;
        SetData(); 
        check();
    }//GEN-LAST:event_backActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feetf.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(OnlineTestFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(OnlineTestFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(OnlineTestFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(OnlineTestFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new OnlineTestFrame().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton back;
    private javax.swing.ButtonGroup bg;
    private javax.swing.JButton bt1;
    private javax.swing.JButton bt10;
    private javax.swing.JButton bt2;
    private javax.swing.JButton bt3;
    private javax.swing.JButton bt4;
    private javax.swing.JButton bt5;
    private javax.swing.JButton bt6;
    private javax.swing.JButton bt7;
    private javax.swing.JButton bt8;
    private javax.swing.JButton bt9;
    private javax.swing.JButton clear;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JRadioButton jb1;
    private javax.swing.JRadioButton jb2;
    private javax.swing.JRadioButton jb3;
    private javax.swing.JRadioButton jb4;
    private javax.swing.JLabel l2;
    private javax.swing.JButton next;
    private javax.swing.JButton submit;
    private javax.swing.JTextArea tf;
    // End of variables declaration//GEN-END:variables
}
